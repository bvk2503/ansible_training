#! /usr/bin/python

def sayHello(msg):
    print ("Hello " + str(msg) )

sayHello('Python!')
sayHello(10)
